gcc Salespoint.c
./a.out
echo Program is Started now !
